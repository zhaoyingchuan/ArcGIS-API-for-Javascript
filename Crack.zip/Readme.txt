
 ______   _______  _        _______  _______  _______  _       
(  __  \ (  ___  )( (    /|(  ____ )(  ___  )(  ____ \| \    /\
| (  \  )| (   ) ||  \  ( || (    )|| (   ) || (    \/|  \  / /
| |   ) || (___) ||   \ | || (____)|| (___) || |      |  (_/ / 
| |   | ||  ___  || (\ \) ||  _____)|  ___  || |      |   _ (  
| |   ) || (   ) || | \   || (      | (   ) || |      |  ( \ \ 
| (__/  )| )   ( || )  \  || )      | )   ( || (____/\|  /  \ \
(______/ |/     \||/    )_)|/       |/     \|(_______/|_/    \/
                                                               

Instructions:	Unrar and install the app v3.0.x
			When finshed Make sure that ArcGIS Pro is not opened.
			Copy "AfCore.dll" to the <installdir>
			Import "lic.reg" to the registry.
			Copy folder "ESRI_Licensing\" to the folder "C:\Users\{username}\AppData\Local\"

Note: ESRI_Licensing is hidden folder
========================
By  i-ARer ;  Repack Daniel Lau.